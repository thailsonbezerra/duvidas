package thailson.bluefood.util;

public enum FileType {

	PNG("image/png", "png"),
	JPG("image/jpeg", "jpg");
	
	String mimeType;
	String extesion;
	
	FileType(String mimeType, String extesion){
		this.mimeType = mimeType;
		this.extesion = extesion;
	}
	
	public String getExtesion() {
		return extesion;
	}
	
	public String getMimeType() {
		return mimeType;
	}
	
	public boolean sameOf(String mimeType) {
		return this.mimeType.equals(mimeType);
	}
	
	public static FileType of(String mimeType) {
		for (FileType fileType : values()) {
			if(fileType.sameOf(mimeType)) {
				return fileType;
			}
		}
		
		return null;
	}
}
