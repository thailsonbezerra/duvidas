package thailson.bluefood.domain.restaurante;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ItemCardapaioRepository extends JpaRepository<ItemCardapio, Integer> {

}
