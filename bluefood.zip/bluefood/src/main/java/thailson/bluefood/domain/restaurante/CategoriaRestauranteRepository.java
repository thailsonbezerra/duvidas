package thailson.bluefood.domain.restaurante;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoriaRestauranteRepository extends JpaRepository<CategoriaRestaurante, Integer> {

}
