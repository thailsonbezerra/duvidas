package thailson.bluefood.infrastructure.web.security;

public enum Role {

	CLIENTE, RESTAURANTE;
}
